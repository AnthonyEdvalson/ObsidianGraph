﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Connection : MonoBehaviour
{
    public Node Source;
    public Node Target;

    void OnMouseDown()
    {
        Target.Unlink(Source);
        Destroy(gameObject);
    }
}
