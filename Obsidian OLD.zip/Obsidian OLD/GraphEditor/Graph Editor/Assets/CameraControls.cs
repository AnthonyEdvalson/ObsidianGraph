﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControls : MonoBehaviour {

    public float Sensitivity = 1;
    public float Speed = 1;
    public float ZoomSpeed = 1;
    public float MinSize = 1;
    public float FastSpeed = 3;
    public Camera cam;
    public static float ViewSize = 0;

    void Start()
    {
        cam = GetComponent<Camera>();
    }

	public void Update()
    {
        float fast = Mathf.Lerp(1, FastSpeed, Input.GetAxis("FastMove"));

        Vector2 move = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"));

        if (move.sqrMagnitude > 1)
            move.Normalize();

        if (Input.GetMouseButton(2))
            move += new Vector2(-Input.GetAxis("Mouse X"), -Input.GetAxis("Mouse Y")) * Sensitivity;

        move *= Time.unscaledDeltaTime;
        move *= Speed;
        move *= cam.orthographicSize;
        move *= fast;
        

        float zoom = Input.GetAxis("Mouse ScrollWheel") + Input.GetAxis("Zoom");
        zoom *= Time.unscaledDeltaTime;
        zoom *= ZoomSpeed;
        zoom *= fast;

        if (zoom > 0)
            cam.orthographicSize += (cam.orthographicSize - MinSize) * -zoom;
        else if (zoom < 0)
            cam.orthographicSize += cam.orthographicSize * -zoom;

        ViewSize = cam.orthographicSize;

        transform.position += (Vector3)move;
    }
}
