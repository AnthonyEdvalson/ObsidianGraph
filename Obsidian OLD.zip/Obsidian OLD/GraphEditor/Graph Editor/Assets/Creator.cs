﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Creator : MonoBehaviour
{
    public GameObject NodePrefab;

    void OnMouseDown() {
        if (Input.GetButton("Jump")) {
            Vector3 point = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            point.Scale(new Vector3(1, 1, 0));
            GameObject go = GameObject.Instantiate(NodePrefab, point, Quaternion.identity);
        }
    }
}
