﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent( typeof(LineRenderer) )]
public class CurvedLineRenderer : MonoBehaviour 
{
	//PUBLIC
	public float lineSegmentSize = 0.15f;
	public float lineWidth = 0.1f;
	public Transform[] points = new Transform[] {};
	//PRIVATE
	private Vector3[] linePositionsOld = new Vector3[0];

	// Update is called once per frame
	public void Update () 
	{
		//create old positions if they dont match
		if( linePositionsOld.Length != points.Length )
		{
			linePositionsOld = new Vector3[points.Length];
		}

		//check if line points have moved
		bool moved = false;
		for( int i = 0; i < points.Length; i++ )
		{
			//compare
			if( points[i].position != linePositionsOld[i] )
			{
				moved = true;
				linePositionsOld[i] = points[i].position;
			}
		}

		//update if moved
		if( moved )
		{
			LineRenderer line = this.GetComponent<LineRenderer>();

			//get smoothed values
			Vector3[] smoothedPoints = LineSmoother.SmoothLine( points, lineSegmentSize );

			//set line settings
			line.positionCount = smoothedPoints.Length;
			line.SetPositions( smoothedPoints );
			line.startWidth = lineWidth;
			line.endWidth = lineWidth;

			MeshCollider meshCollider = this.GetComponent<MeshCollider>();
			Mesh mesh = new Mesh();
			line.BakeMesh(mesh, true);
			meshCollider.sharedMesh = mesh;
		}
	}

	void OnDrawGizmos() {
		Update();
	}
}
