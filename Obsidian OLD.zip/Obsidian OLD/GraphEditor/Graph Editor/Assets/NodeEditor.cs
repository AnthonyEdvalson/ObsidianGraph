﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using System;

[Serializable]
class NodeData {
    public string name;
    public string file;
    public string side;
    public List<string> inputs;
}

[Serializable]
class GraphData {
    public List<NodeData> nodes = new List<NodeData>();
}

public class NodeEditor : MonoBehaviour
{
    public static NodeEditor main;
    public InputField Name;
    public InputField Side;

    private void Start() {
        main = this;
    }

    private Node editing;

    public void Open(Node node)
    {
        editing = node;
        Name.text = node.Name;
        Side.text = node.Side;
    }

    public void Save()
    {
        Node[] nodes = FindObjectsOfType<Node>();

        var result = new GraphData();

        foreach (Node node in nodes)
        {
            var nd = new NodeData();
            nd.name = node.Name;
            nd.file = node.File;
            nd.side = node.Side;
            nd.inputs = new List<string>();

            foreach (Node input in node.Inputs)
            {
                nd.inputs.Add(input.Name);
            }

            result.nodes.Add(nd);
        }

        string jsonString = JsonUtility.ToJson(result);
        string fileName = @"C:\Users\tonye\Documents\Projects\Jobs\Obsidian\Graph\pack\graph2.json";
        File.WriteAllText(fileName, jsonString);
    }

    public void OnChangeName(string s)
    {
        editing.Name = s;
        editing.File = "pack/files/" + s + ".py";
    }

    public void OnChangeSide(string s)
    {
        editing.Side = s;
    }
}
