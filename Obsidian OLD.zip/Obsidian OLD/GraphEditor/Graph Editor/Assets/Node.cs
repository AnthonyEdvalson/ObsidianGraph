﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Node : MonoBehaviour
{
    private bool dragging = false;
    private bool hover = false;
    private float distance;
    private Vector3 targetPos;
    private float snap = 0.25f;
    
    public string Name;
    public string File;
    public string Side = "back";
    public List<Node> Inputs = new List<Node>();
    public GameObject LinePrefab;
    public Transform InputAnchor;
    public Transform OutputAnchor;

    void OnMouseEnter()
    {
        hover = true;
    }
 
    void OnMouseExit()
    {
        hover = true;
    }
 
    void OnMouseDown()
    {
        distance = Vector3.Distance(transform.position, Camera.main.transform.position);
        dragging = true;
        NodeEditor.main.Open(this);
    }
 
    void OnMouseUp()
    {
        dragging = false;
    }
 
    void Update()
    {
        if (dragging)
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            targetPos = ray.GetPoint(distance);
            transform.position = new Vector3((int)(targetPos.x / snap) * snap, (int)(targetPos.y / snap) * snap, transform.position.z);
        }
    }

    public void Link(Node input) {
        Inputs.Add(input);

        GameObject go = GameObject.Instantiate(LinePrefab, Vector3.zero, Quaternion.identity);
        var clr = go.GetComponent<CurvedLineRenderer>();
        clr.points = new Transform[] { InputAnchor, input.OutputAnchor };

        var con = go.GetComponent<Connection>();
        con.Source = input;
        con.Target = this;
    }

    public void Unlink(Node input) {
        Inputs.Remove(input);
    }
}
