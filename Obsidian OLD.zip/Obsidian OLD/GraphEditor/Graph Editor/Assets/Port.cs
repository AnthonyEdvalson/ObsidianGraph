﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Port : MonoBehaviour
{
    private bool connecting = false;
    private bool hover = false;
    private Node parent;

    void Start()
    {
        parent = transform.parent.GetComponent<Node>();
    }

    void OnMouseEnter()
    {
        hover = true;
    }
 
    void OnMouseExit()
    {
        hover = true;
    }
 
    void OnMouseDown()
    {
        connecting = true;
    }
 
    void OnMouseUp()
    {
        Vector3 point = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        Debug.DrawRay(point, Vector3.forward * 200, Color.white, 10);
        Collider2D[] cs = Physics2D.OverlapPointAll(point);

        foreach (Collider2D c in cs)
        {
            Node d = c.GetComponent<Node>();
            if (d)
            {
                parent.Link(d);
            }
        }

        connecting = false;
    }
}
