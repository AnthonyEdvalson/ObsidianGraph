from obsidian import ObsidianPackage
from peewee import *


Ducklopedia = ObsidianPackage("ducklopedia")


class Duck(Ducklopedia.Model):
    name = CharField()
    buoyancy = FloatField()
    content = CharField()
    rating = IntegerField()
    featured = BooleanField()


class User(Ducklopedia.Model):
    firstName = CharField()
    lastName = CharField()
    password = CharField()
    referredBy = ForeignKeyField('self', null=True)


class Favorite(Ducklopedia.Model):
    user = ForeignKeyField(User, backref="favorites")
    duck = ForeignKeyField(Duck, backref="favorited")


class DuckController(Ducklopedia.CrudObject):
    name = "Duck"
    _model = Duck

    @staticmethod
    def get_top_10():
        return Duck.select().order_by(Duck.rating.desc()).limit(10)

    @staticmethod
    def get_top_3():
        return Duck.select().order_by(Duck.rating).limit(3)


class UserController(Ducklopedia.CrudObject):
    name = "User"
    _model = User


class FavoriteController(Ducklopedia.MtMObject):
    name = "Favorite"
    _model = Favorite
