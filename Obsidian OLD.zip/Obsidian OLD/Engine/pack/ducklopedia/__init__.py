from packOLD.ducklopedia.ducklopedia import Ducklopedia
