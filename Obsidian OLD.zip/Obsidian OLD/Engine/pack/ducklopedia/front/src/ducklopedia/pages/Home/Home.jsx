import React from 'react';
import './Home.css';
import {Container, Jumbotron, Row, Col} from "react-bootstrap";
import TopDucks from './TopDucks/TopDucks';
import Obsidian from '../../../obsidian';


class Home extends React.Component{
	constructor(props) {
		super(props);
		this.state = {worst: []};
		this.remote = new Obsidian.Server("ducklopedia");

	}

	componentDidMount() {
		this.remote.please("get_top_3", "duck").then(data => {
			this.setState({worst: data});
		});
	}

	render()
	{
	let splash = "Quack.";

		return (
			<div className="Home">
				<Jumbotron fluid>
					<Container>
						<h1>...</h1>
						<p>
						  {splash}
						</p>
					</Container>
				</Jumbotron>
        <Container>
          <Row>
            <Col>
              <h2>Top 10</h2>
              <TopDucks></TopDucks>
            </Col>
            <Col>
			  <h2>Featured</h2>
			  <ol>
			  {this.state.worst.map((value, i) => {
				  return <li key={value.id}>{value.name} {value.id}</li>
			  })}
			  </ol>
            </Col>
          </Row>
        </Container>
			</div>
		);
	}
}

export default Home;
