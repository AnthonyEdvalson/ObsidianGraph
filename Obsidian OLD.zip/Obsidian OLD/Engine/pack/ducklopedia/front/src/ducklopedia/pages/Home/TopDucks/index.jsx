import TopDucks from './TopDucks';
export default TopDucks;