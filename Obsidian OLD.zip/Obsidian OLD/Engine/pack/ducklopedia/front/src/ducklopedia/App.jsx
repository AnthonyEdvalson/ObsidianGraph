import React from 'react';
import './App.css';
import { Switch, Route } from 'react-router-dom';
import Home from "./pages/Home";
import Duck from "./pages/Duck";
import User from "./pages/User";
import Obsidian from "../obsidian";
import Nav from "./Nav";


class App extends React.Component{
  render()
  {
    return (
      <div className="App">
        <Obsidian.Toolbar />
        <Nav />
        <Switch>
          <Route exact path='/' component={ Home } />
          <Route path='/duck/:id' component={ Duck } />
          <Route path='/user/:id' component={ User } />
        </Switch>
      </div>
    );
  }
}

export default App;
