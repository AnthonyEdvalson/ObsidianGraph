import React from 'react';
import './Duck.css';
import Obsidian, { useEntry } from '../../../obsidian';


const remote = new Obsidian.Server("ducklopedia");


function Duck(props) {
    let isNew = props.match.params.id === "new";
    let id = isNew ? undefined : props.match.params.id;
    let getVerb = isNew ? "get_new" : "get";
    let setVerb = isNew ? "insert" : "update";

    let entry = useEntry(remote, "duck", {id}, getVerb, setVerb);

    return (
        <div className="Duck">
            <span>{JSON.stringify(entry.data)}</span>
        </div>
    );
}

export default Duck;
