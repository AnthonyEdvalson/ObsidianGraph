import Duck from './Duck';
export default Duck;