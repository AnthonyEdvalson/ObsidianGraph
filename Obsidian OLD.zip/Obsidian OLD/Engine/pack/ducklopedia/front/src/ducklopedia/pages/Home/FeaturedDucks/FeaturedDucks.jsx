import React from 'react';
import './FeaturedDucks.css';

class FeaturedDucks extends React.Component{
	constructor(props) {
		super(props);
		this.state = {}
	}

	render()
	{
		return (
			<div className="FeaturedDucks">
				...
			</div>
		);
	}
}

export default FeaturedDucks;
