import React from 'react';
import './Duck.css';
import { Input } from 'forms';
import Obsidian from 'obsidian';
import { Prompt } from 'react-router-dom';

class Duck extends React.Component{
	constructor(props) {
		super(props);
		this.remote = new Obsidian.Server("ducklopedia");
	}

	render()
	{
		let isNew = this.props.match.params.id === "new";
		let id = isNew ? undefined : this.props.match.params.id;

		return (
			<div className="Duck">
				<Obsidian.Entry new={isNew} remote={this.remote} object={"duck"} args={{id: id}}>
					{ e => (
						<div>
							<Input t="str" entry={e.attr("name")} />
							<Input t="num" entry={e.attr("buoyancy")} min={0} max={1}/>
							<Input t="num" entry={e.attr("rating")} min={0}/>
							<Input t="text" entry={e.attr("content")} />
							<Input t="bool" entry={e.attr("featured")} />
							<button onClick={e.save}>SAVE</button>
							<button onClick={e.delete}>DELETE</button>
							<Prompt when={e.dirty} message='You have unsaved changes, are you sure you want to leave?' />
						</div>
					)}
				</Obsidian.Entry>
			</div>
		);
	}
}

export default Duck;
