import FeaturedDucks from './FeaturedDucks';
export default FeaturedDucks;