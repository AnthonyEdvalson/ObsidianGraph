import React from 'react';
import './User.css';
import Obsidian from '../../../obsidian';
import { Input, Pick, Picks } from '../../../forms';
import { Prompt } from 'react-router-dom';


class User extends React.Component{
	constructor(props) {
		super(props);
		this.remote = new Obsidian.Server("ducklopedia");
	}

	render()
	{
		let id = this.props.match.params.id;

		return (
			<div className="User">
				<Obsidian.Entry new={id === "new"} remote={this.remote} object={"user"} args={{id: id === "new" ? undefined : id}}>
					{ e => (
						<div>
							<Input t="str" entry={e.attr("firstName")} />
							<Input t="str" entry={e.attr("lastName")} />
							<Input t="pass" entry={e.attr("password")} />
							<Pick entry={e.attr("referredBy")} from="User" remote={this.remote}>
								{
									v => v ? v.firstName + " " + v.lastName : "Pick a referrer"
								}
							</Pick>
							
							<Picks rel="Favorites" that="duck" remote={this.remote}>
								{
									v => v ? v.name + " (" + v.rating + ")" : "Pick a referrer"
								}
							</Picks>
							<button onClick={e.save}>SAVE</button>
							<button onClick={e.delete}>DELETE</button>
							<Prompt when={e.dirty} message='You have unsaved changes, are you sure you want to leave?' />
						</div>
					)}
				</Obsidian.Entry>
			</div>
		);
	}
}

export default User;
