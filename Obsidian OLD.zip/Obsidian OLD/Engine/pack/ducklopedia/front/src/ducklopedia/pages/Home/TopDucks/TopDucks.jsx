import React from 'react';
import './TopDucks.css';
import Obsidian from '../../../../obsidian';

class TopDucks extends React.Component{
	constructor(props) {
		super(props);
		this.state = {
      ducks: [],
      loading: true
    };

    this.ducklopedia = new Obsidian.Server("ducklopedia");
  }
  
  componentDidMount() {
    this.ducklopedia.please("get_top_10", "duck").then(
      data => {
        this.setState({ducks: data, loading: false});
      }
    );
  }

	render()
	{
		return (
			<div className="TopDucks">
        {this.state.loading ? 'Loading...' : (
          <ol>
            {this.state.ducks.map((duck, i) => {
              return (
                <li key={duck.id}><a href={"/duck/" + duck.id}>{duck.name}</a></li>
              )
            })}
          </ol>
        )}
			</div>
		);
	}
}

export default TopDucks;
