from peewee import *

from obsidian import ObsidianPackage
import subprocess
import sys
import engine

obsidian = ObsidianPackage("obsidian")

"""
@obsidian.route
def get(table, col, value):
    pass  # db_call("SELECT * FROM ? WHERE ?=?")


@obsidian.route
def delete(table, col, value):
    pass


@obsidian.route
def insert(table, cols, values):
    assert len(cols) == len(values)
    # command = "INSERT INTO ? ({}) VALUES({}) ON CONFLICT()".format(",?" * len(cols))


@obsidian.route
def gets(table, limit=None, sort=None):
    command = "SELECT * FROM ?", [table]

    if sort:
        command = command[0] + " ORDER BY ?", [*command[1], sort]

    if limit:
        command = command[0] + "LIMIT ?", [*command[1], limit]

    # db_call(*command)
"""

COMMON_EDITORS_OSX = {
  # '/Applications/Visual Studio Code.app/Contents/MacOS/Electron': 'code',
  '/Applications/PyCharm.app/Contents/MacOS/pycharm': '/Applications/PyCharm.app/Contents/MacOS/pycharm',
  '/Applications/PyCharm CE.app/Contents/MacOS/pycharm': '/Applications/PyCharm CE.app/Contents/MacOS/pycharm',
}

COMMON_EDITORS_LINUX = {
  # 'code': 'code',
  'pycharm.sh': 'pycharm',
}

COMMON_EDITORS_WIN = [
  # 'Code.exe',
  'pycharm.exe',
  'pycharm64.exe',
]


class Source(obsidian.Object):
    def open(self, file, lineno):
        # TODO Only tested on OSX, probably won't work anywhere else
        p = sys.platform
        app = None
        if p == "linux":
            # bank = COMMON_EDITORS_LINUX
            pass
        elif p == "darwin":
            # bank = COMMON_EDITORS_OSX
            app = "/Applications/PyCharm.app/Contents/MacOS/pycharm"
        elif p == "win32":
            # bank = COMMON_EDITORS_WIN
            app = "C:\\Program Files (x86)\\JetBrains\\PyCharm 2016.2.3\\bin\\pycharm.exe"

        # app = "/Applications/Visual Studio Code.app/Contents/MacOS/Electron"
        # app = "/Applications/PyCharm.app/Contents/MacOS/pycharm"

        try:
            subprocess.Popen([app, "--line", str(lineno), file])
            # subprocess.Popen(["open", "-a", app])
        except Exception as e:
            raise Exception("Failed to open {}:{} due to the following error:\n{}".format(file, lineno, e))


#class Route(obsidian.Object):
#    def explain(self, keys):
#        return engine.router.route(keys).options()
