import React from 'react';
import { PieChart, Pie, ResponsiveContainer, Cell } from 'recharts';

function Activity(props) {
    let goalStatus = props.goalStatus;
    let progress = goalStatus.progress;
    let target = goalStatus.target;
    let activity = goalStatus.activity;

    let pieData = [
        {name: "completed", value: progress, color: activity.color},
        {name: "remaining", value: target - progress + 0.000001, color: "#31373D"}
    ];

	return (
        <div className={progress >= target ? "Activity complete" : "Activity"}>
             <ResponsiveContainer height="100%" width={270}>
                <PieChart>
                    <Pie data={pieData} outerRadius="85%" fill={activity.color} stroke="rgba(0, 0, 0, 0)">
                        {
                            pieData.map((entry, index) => <Cell key={index} fill={entry.color}/>)
                        }
                    </Pie>
                </PieChart>
            </ResponsiveContainer>
            <span className="act-name">{activity.name}</span>
            <div className="act-status">
                <span className="act-progress">{progress.toFixed(1)}</span>/<span className="act-target">{target.toFixed(1)}</span>
            </div>
        </div>
    );
}

export default Activity;
