import React from 'react';
import './SidebarList.css'

class EditorSidebar extends React.Component{
  constructor(props)
  {
    super(props);
    this.state = {collapse: true};
    this.handleToggleColapse = this.handleToggleColapse.bind(this);
  }

  handleToggleColapse()
  {
    this.setState({collapse: !this.state.collapse});
  }

  render()
  {
    let listClass = "SidebarList";
    if (this.state.collapse)
      listClass += " collapse";

    return (
      <div className={listClass}>
        <h3 onClick={this.handleToggleColapse}>{this.props.name}</h3>
        <ul>
          {this.props.items && this.props.items.map((val, i) => {
            return <li onClick={() => this.props.onClick(i)}>val</li>
          })}
          <li className="new" onClick={this.props.onNew}>+ Create New</li>
        </ul>
      </div>
    );
  }
}

export default EditorSidebar;
