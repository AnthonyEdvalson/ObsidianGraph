import React from 'react';
import SidebarList from './SidebarList/SidebarList';
import './PageEditor.css'

class EditorSidebar extends React.Component{
  constructor(props)
  {
    super(props);
    this.state = {collapse: false};
    this.handleToggleCollapse = this.handleToggleCollapse.bind(this);
  }

  handleToggleCollapse()
  {
    this.setState({collapse: !this.state.collapse});
  }

  content()
  {
    if (this.props.app)
    {
      return (
        <div>
          <h2>NAVIGATOR</h2>
          <SidebarList list={this.props.app.templates} name='TEMPLATES' />
          <SidebarList list={this.props.app.pages} name='PAGES' />
          <SidebarList list={this.props.app.components} name='COMPONENTS' />
        </div>
      );
    }
    else
    {
      return <span>Loading...</span>
    }
  }

  render()
  {
    let sidebarClass = "EditorSidebar";
    if (this.state.collapse)
      sidebarClass += " collapse"

    return (
      <div className={sidebarClass}>
        <div className="hamburger" onClick={this.handleToggleCollapse}></div>
        {this.content()}
      </div>
    );
  }
}

export default EditorSidebar;
