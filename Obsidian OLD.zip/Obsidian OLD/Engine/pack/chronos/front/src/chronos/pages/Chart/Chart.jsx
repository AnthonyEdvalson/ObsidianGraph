import React from 'react';
import './Chart.css';
import Obsidian, { useEntry } from '../../../obsidian';
import Activity from './Activity';
import { PieChart, Pie, ResponsiveContainer, Cell } from 'recharts';

/**
 * Chart stuff took a while
 * 2hr - scaffolding and getting everything in place
 * 2hr - populating database, fixing issue with query
 * 1.5hr - styling and aligning stuff, turns out using flexbox always makes it easier
 */

let remote = new Obsidian.Server("chronos");

function Content(props) {
    let e = props.entry;

    if (!e.loaded)
        return (<div className="loading">...</div>);

    let mainChart = [{name: "default", value: 0.0000001, color: " #31373D"}];
    e.data.forEach(v => {
        mainChart.push({value: v.progress, name: v.activity.name, color: v.activity.color});
    });

    return (
        <>
            <div className="activities">
            {
                e.data.map((value, i) => {
                    return <Activity key={i} goalStatus={value} />
                })
            }
            </div>
            <div className="main-chart">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                          data={mainChart}
                          innerRadius={"37.5%"}
                          outerRadius={"75%"}
                          stroke="rgba(0, 0, 0, 0)"
                        >
                            {
                                mainChart.map((entry, index) => <Cell key={index} fill={entry.color}/>)
                            }
                        </Pie>
                    </PieChart>
                </ResponsiveContainer>
            </div>
        </>
    );
}

function Chart() {
    let e = useEntry(remote, "goal", {}, "get_completion");

	return (
		<div className="Chart">
            <Content entry={e} />
		</div>
	);
}

export default Chart;
