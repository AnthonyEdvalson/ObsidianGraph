import React from 'react';
import './App.css';
import { Switch, Route } from 'react-router-dom';
import AppSelect from './AppSelect';
import AppEdit from './AppEdit';


class App extends React.Component{
  constructor(props)
  {
    super(props);
    this.state = {};
  }

  render()
  {
    return (
        <div className="App">
            <Switch>
                <Route exact path='/' component={ AppSelect } />
                <Route path='/app/:name' component={ AppEdit } />
            </Switch>
        </div>
    );
  }
}

export default App;
