import React from 'react';
import SidebarList from './SidebarList/SidebarList';
import './EditorSidebar.css';
import Obsidian from 'obsidian';

class EditorSidebar extends React.Component{
  constructor(props)
  {
    super(props);
    this.state = {collapse: false};
    this.handleToggleCollapse = this.handleToggleCollapse.bind(this);
    this.handleCompenentNew = this.handleCompenentNew.bind(this);
    this.handleComponentClick = this.handleComponentClick.bind(this);
  }

  handleToggleCollapse()
  {
    this.setState({collapse: !this.state.collapse});
  }

  handleComponentClick(i) {
    return () => {
      console.log(i);
    }
  }

  handleCompenentNew() {
    let new_comp = Obsidian.post("component/new");
    console.log(new_comp);
  }

  content()
  {
    if (this.props.app)
    {
      return (
        <div>
          <h2>NAVIGATOR</h2>
          <SidebarList list={this.props.app.templates} name='TEMPLATES' />
          <SidebarList list={this.props.app.pages} name='PAGES' />
          <SidebarList list={this.props.app.components} onClick={this.handleComponentClick} onNew={this.handleCompenentNew} name='COMPONENTS' />
        </div>
      );
    }
    else
    {
      return <span>Loading...</span>
    }
  }

  render()
  {
    return (
      <div className={this.state.collapse ? "collapse" : ""}>
        <div className="EditorSidebar">
          <div className="hamburger" onClick={this.handleToggleCollapse}></div>
          {this.content()}
        </div>
        <div className="EditorTopbar">
          <h2>{this.props.app ? this.props.app.name : ""}</h2>
          <span>Settings</span>
          <span>Close</span>
        </div>
      </div>
    );
  }
}

export default EditorSidebar;
