import React from 'react';
import Obsidian from "obsidian";
import EditorSidebar from './EditorSidebar';

class AppEdit extends React.Component{
  constructor(props)
  {
    super(props);
    this.state = {app: null};
  }

  componentDidMount() {
    Obsidian.post("app/get", {name: this.props.match.params.name}).then(
      data => {
        this.setState({app: data});
      }
    );
  }

  render()
  {
    return (
      <div className="AppEdit">
        <h2>{this.props.name}</h2>
        <EditorSidebar app={this.state.app}/>
        <div className="EditorWindow">

        </div>
      </div>
    );
  }
}

export default AppEdit;
