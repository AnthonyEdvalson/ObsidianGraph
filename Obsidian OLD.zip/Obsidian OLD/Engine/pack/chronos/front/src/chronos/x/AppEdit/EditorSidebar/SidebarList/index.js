import SidebarList from './SidebarList';

export default SidebarList;