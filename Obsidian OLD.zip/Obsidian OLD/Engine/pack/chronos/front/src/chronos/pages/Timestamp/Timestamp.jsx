import Obsidian, { useEntry } from '../../../obsidian';
import React from 'react';

let remote = new Obsidian.Server("chronos");

function Timestamp() {
    let e = useEntry(remote, "timestamp", {}, "get_all");

    return (
        <div className="Timestamp">

        </div>
    )
}

export default Timestamp;