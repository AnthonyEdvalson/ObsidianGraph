import React from 'react';
import './Home.css';
import {Container, Jumbotron, Row, Col} from "react-bootstrap";
import Obsidian from '../../../obsidian';


class Home extends React.Component{
	constructor(props) {
		super(props);
		this.remote = new Obsidian.Server("ducklopedia");

	}

	componentDidMount() {
	}

	render()
	{
	let splash = "Quack.";

		return (
			<div className="Home">
				<Jumbotron fluid>
					<Container>
						<h1>...</h1>
						<p>
						  {splash}
						</p>
					</Container>
				</Jumbotron>
        <Container>
          <Row>
            <Col>
              <h2>Top 10</h2>
            </Col>
            <Col>
			  <h2>Featured</h2>
            </Col>
          </Row>
        </Container>
			</div>
		);
	}
}

export default Home;
