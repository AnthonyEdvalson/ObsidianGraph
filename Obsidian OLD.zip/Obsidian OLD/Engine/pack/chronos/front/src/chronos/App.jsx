import React from 'react';
import './App.css';
import { Switch, Route } from 'react-router-dom';
import Home from "./pages/Home";
import Chart from "./pages/Chart";
import Obsidian from "../obsidian";
import Nav from "./Nav";
import Timestamp from './pages/Timestamp/Timestamp';


class App extends React.Component{
  render()
  {
    return (
      <div className="App">
        <Obsidian.Toolbar />
        <Nav />
        <Switch>
          <Route exact path='/' component={ Home } />
          <Route exact path='/chart' component={ Chart } />
          <Route exact path='/timestamp' component={Timestamp} />
        </Switch>
      </div>
    );
  }
}

export default App;
