import React from 'react';
import './index.css';
import Obsidian from 'obsidian';
import Ducklopedia from "../ducklopedia";


class AppTile extends React.Component{
  static contextType = Ducklopedia;

  constructor(props)
  {
    super(props);

    if (props.type === "add")
    {
      this.new = true;
      this.name = "";
    }
    else
    {
      this.new = false;
      this.name = props.name;
    }

    this.state = {};
    this.clicked = this.clicked.bind(this);
  }

  clicked() {
      window.location = "/app/" + this.name;
  }

  createNew() {
    this.context.call("app/new").then((data) => {
      window.location = "/app/" + data.name;
    });
  }

  render()
  {
    if (this.new)
    {
      return (
        <div className="AppTile" onClick={this.createNew}>
          <h2>+ New App</h2>
        </div>
      );
    }
    else
    {
      return (
        <div className="AppTile" onClick={this.clicked}>
          <h2>{this.name}</h2>
        </div>
      );
    }
  }
}

export default AppTile;
