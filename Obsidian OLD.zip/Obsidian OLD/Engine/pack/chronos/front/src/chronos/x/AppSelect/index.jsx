import React from 'react';
import AppTile from "../AppTile";
import Ducklopedia from "../ducklopedia";

class AppSelect extends React.Component{
  static contextType = Ducklopedia;
  constructor(props)
  {
    super(props);
    this.state = {names: []};
  }

  componentDidMount() {
    this.context.call("names").then(
      data => {
        this.setState({"names": data});
      }
    );
  }

  render()
  {
    return (
      <div className="AppSelect">
        <h1>Obsidian</h1>
        {this.state.names.map((value, index) => {
          return <AppTile key={value} name={value} />
        })}
        <AppTile type='add'/>
      </div>
    );
  }
}

export default AppSelect;
