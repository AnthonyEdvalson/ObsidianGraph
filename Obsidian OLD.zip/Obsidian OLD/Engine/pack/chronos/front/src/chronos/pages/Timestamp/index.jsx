import Timestamp from './Timestamp';

export default Timestamp;