import EditorSidebar from './EditorSidebar';

export default EditorSidebar;