

function PieChart(props) {
    let values = props.values;

    values.forEach(v => {

    });
}

export default PieChart;