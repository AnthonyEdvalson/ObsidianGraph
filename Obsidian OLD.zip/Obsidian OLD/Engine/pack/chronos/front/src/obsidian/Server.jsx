import ErrorPage from './ErrorPage';
import React from 'react';
import ReactDOM from 'react-dom';
import StackTrace from 'stacktrace-js';

var $ = require("jquery");

function getStacktrace(error) {
  return StackTrace.fromError(error).then(trace => {
    let st =trace.map(frame => {
      return {
        file: frame.fileName || "...",
        frame: frame.functionName || "...",
        line: "...",
        lineno: frame.lineNumber || 1,
        important: !frame.fileName.includes("node_modules")
      };
    });
    st.reverse();
    st.pop(); // TODO instead of pop, it should label the obsidian frames as not important, and highlight the first frame made by the user
    return st;
  });
}

class Server {
  constructor(pack) {
    this.pack = pack;
  }

  please(verb, obj, args={}) {
    if (args === null || (typeof args) !== "object")
      throw Error("Args should be an object containing argument names and values, not '" + (typeof args) + "'");
    if (typeof verb !== "string")
      throw Error("verb should be a string, but was " + typeof verb);
    if (typeof obj !== "string")
      throw Error("obj should be a string, but was " + typeof verb);

    let requestJson = JSON.stringify({
      v: 0,
      pack: this.pack,
      verb,
      obj,
      args
    }, null, 2);
  
    let pinnedError = Error(); // Create an error now that is more useful than if one were made deep into the promises up ahead
  
    return new Promise((resolve, reject) => {
      $.ajax({
        url: `${window.location.protocol}//${window.location.hostname}:5000/call`,
        method: 'POST',
        data: requestJson,
        success: function (data) {
          resolve(JSON.parse(data));
        },
        error: function (xhr, ajaxOptions, thrownError) {
          reject(xhr);
  
          let error = null;
          try {
            error = JSON.parse(JSON.parse(xhr.responseText));
          }
          catch (e) {
            throw new Error("Cannot parse " + xhr.responseText);
          }
  
          let fsp = getStacktrace(pinnedError);
  
          fsp.then(fst => {
            this.obsidian = new Server("obsidian");
            var elem = React.createElement(ErrorPage, {error, remote: this.obsidian, frontStack: fst, requestJson});
            ReactDOM.render(elem, document.getElementById('root'));
          });
        }
      });
    });
  }
}

export default Server;
