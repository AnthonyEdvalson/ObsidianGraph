import React from 'react';
import './Modal.css';

class Modal extends React.Component{
	constructor(props) {
		super(props);
	}

	render()
	{
		if (!this.props.shown)
			return null;

		return (
			<div className="Modal">
				<div className="content">
					{React.cloneElement(this.props.children, this.props.props)}
				</div>
			</div>
		);
	}
}

export default Modal;
