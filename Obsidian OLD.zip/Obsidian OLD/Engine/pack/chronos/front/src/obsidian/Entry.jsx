import { useState, useEffect } from 'react';

function useEntry(remote, object, loadArgs, loadVerb, saveVerb, delVerb) {
	const [state, setState] = useState({
		loading: true, // True if in the process of updating the data
		loaded: false, // True if data is set
		dirty: false, // True if the data in the Entry is different than what would be returned if data was loaded from the server
		saving: false, // True if the server is in the process of updating data on the server
		error: null, // details of any errors when communicating with the server, resets on every request
		data: null // The working copy of information, automatically passed to delete and update as the parameter "data"
	});

	function load() {
		let verb = loadVerb || "get";

		setState({loading: true});
		return remote.please(verb, object, loadArgs).then(data => {
			setState({loading: false, loaded: true, dirty: false, error: null, data});
		}).catch(error => {
			setState({loading: false, error});
		});
	}

	function save() {
		let verb = saveVerb || "set";

		setState({saving: true});
		return remote.please(verb, object, {data: state.data}).then(data => {
			setState({loaded: true, dirty: false, saving: false, error: null, data});
		}).catch(error => {
			setState({saving: false, error});
		});
	}

	function del() {
		let verb = delVerb || "delete";

		if (!state.loaded)
			return;
		
		setState({loading: true});
        return remote.please(verb, object, {data: state.data}).then(delCount => {
			setState({loading: false, loaded: false, dirty: false, data: null, error: null});
        }).catch(error => {
			setState({loading: false, error});
		});
	}

	function set(value) {
		setState({data: value, dirty: true});
	}

	useEffect(() => {
		load();
		// eslint-disable-next-line
	}, []);

	return {...state, set, load, save, del};
}

export default useEntry;
