import './Toolbar.css';
import React from 'react';
import Server from './Server';


class Toolbar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {modal: null};
  }

  makeCall() {
    var pack = window.prompt("Package", "obsidian");
    var verb = window.prompt("Verb", "get");
    var obj= window.prompt("Object", "");
    var args= JSON.parse(window.prompt("Arguments (JSON)", "{}"));
  
    (new Server(pack)).please(verb, obj, args).then(res => {
      console.log(res);
      window.alert(JSON.stringify(res));
    });
  }
  
  editNav() {
    this.setState({modal: "nav"});
  }

  render()
  {
    let tools = {
      "Request": this.makeCall.bind(this),
      "Navigation": this.editNav.bind(this),
    };

    return (
      <div className="Toolbar">
        <div className="bar">
          {Object.entries(tools).map(([k, v]) => {
            return (
              <div key={k} className="Tool" onClick={v}>
                {k}
              </div>
            )
          })}
        </div>
      </div>
    )
  }
}

export default Toolbar;
