import React from 'react';
import './Picks.css';
//import InputWrapper from '../InputWrapper';
//import Combobox from '../Combobox/Combobox';
import Obsidian from '../../obsidian';

class Picks extends React.Component{
	constructor(props) {
		super(props);
		this.state = {
		};

		this.renderTile = this.renderTile.bind(this);
	}

	renderTile(data, key) {
		return (
			<div className="tile" key={key}>
				{this.props.children(data)}
			</div>
		);
	}

	renderBody(entry) {
		if (!entry.loaded)
			return <div className="tile">Loading...</div>
		
		if (entry.data.length === 0)
			return <div className="tile">No data to display</div>

		return entry.data.map((v, i) => {
			return this.renderTile(v, v.id);
		})
	}

	render()
	{
		let args = {}
		args[this.props.that] = -1;

		return (
			<div className="Picks">
				<Obsidian.Entry remote={this.props.remote} object={this.props.rel} args={args}>
				{
					/*choices => (
						<div>
							<Combobox entry={e} choicesEntry={e} label={this.props.label}>
								{ this.props.children }
							</Combobox>

							<div className="selections">
								{ this.renderBody(e) }
							</div>
						</div>
					)*/
				}
				</Obsidian.Entry>
			</div>
		);
	}
}

export default Picks;
