import DataForm from './DataForm';

export default DataForm;