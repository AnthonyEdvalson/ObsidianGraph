import InputWrapper from './InputWrapper';
export default InputWrapper;