import React from 'react';
import './InputWrapper.css';

function varNameToLabel(varName) {
	// Remove special chars
	let clean = varName.replace(/[^\w\s]/gi, '');

	// Add spaces between groups of lowercase, uppercase, and numbers, except between uppercase followed by lowercase
	// Also, add spaces between uppercase letters in the following case: ABCabc -> AB Cabc  This is to handle abbreviations. TCPSource -> TCP Source
	let spaced = clean.replace(/(?<=[a-z])(?=[A-Z0-9])|(?<=[0-9])(?=[A-z])|(?<=[A-Z])(?=[0-9])|(?<=[A-Z]{2,})(?=[A-Z][a-z])/g, ' ');

	// Enforce title casing, but preserve abbreviations. var -> Var, but TCP -> TCP
	return spaced.replace(/[A-Z]*[a-z][A-z]*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}

function InputWrapper(props)
{
	let label = props.label;
	if (typeof(label) === "undefined" && "name" in props.entry)
		label = varNameToLabel(props.entry.name);

	return (
		<div className={props.entry.loaded ? "InputWrapper" : "InputWrapper loading"}>
			<label>{label}</label>
			{props.children}
		</div>
	);
}


export default InputWrapper;
