import React from 'react';
import './Pick.css';
import '../InputWrapper';
import Combobox from '../Combobox/Combobox';
import Obsidian from '../../obsidian';

class Pick extends React.Component{
	renderTile(data, handleClick, isStatic=false) {
		// TODO make it possible to use a different key
		return (
			<div className={isStatic ? "tile static" : "tile"} key={data ? data.id : undefined} onClick={handleClick}>
				{this.props.children(data)}
			</div>
		);
	}

	render() {
		return (
			<Obsidian.Entry remote={this.props.remote} object={this.props.from} getVerb="get_all">
			{
				e => (
					<Combobox entry={this.props.entry} choicesEntry={e} label={this.props.label}>
						{ this.props.children }
					</Combobox>
				)
			}
			</Obsidian.Entry>
		)
	}
}

export default Pick;
