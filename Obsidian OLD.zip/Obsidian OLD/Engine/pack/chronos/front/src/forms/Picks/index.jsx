import Picks from './Picks';
export default Picks;