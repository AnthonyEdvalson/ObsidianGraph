import React from 'react';
import './Input.css';
import '../InputWrapper';
import InputWrapper from '../InputWrapper';

class Input extends React.Component{

	renderControl(data)
	{
		var t = this.props.t;

		let handle = event => this.props.entry.set(event.target.value);

		if (t === "num") {
			handle = event => this.props.entry.set(parseFloat(event.target.value));
			let min = this.props.min;
			let max = this.props.max;
			let step = this.props.step;

			if (typeof(step) === "undefined" && typeof(min) !== "undefined" && typeof(max) !== "undefined") {
				//10^{\min\left(0,\operatorname{ceil}\left(\log\left(\frac{x}{20}\right)\right)\right)}
				//10 ^ min(0, ceil(log(x / 20)))
				//This is a fancy way of setting the step size smaller for smaller ranges. Step will never be > 1, but if the total range is <= 2 a step size of 1 is usually too big.
				//To fix this, the step is set to 0.1. This repeats, so if range is <= 0.2 the step size drops to 0.01, and so on
				step = Math.pow(10, Math.min(0, Math.ceil(Math.log10((max - min) / 20))));
			}

			return <input type="number" value={data} onChange={handle} min={min} max={max} step={step}/>
		}
		if (t === "bool")
		{
			handle = event => this.props.entry.set(event.target.checked);
			return <input type="checkbox" checked={data} onChange={handle} />
		}
		if (t === "str")
			return <input type="textbox" value={data} onChange={handle} />

		if (t === "pass")
			return <input type="password" value={data} onChange={handle} />
		
		if (t === "text")
			return <textarea value={data} onChange={handle} />


		throw new Error("Cannot create input for type '" + t + "'");
	}

	render()
	{
		let entry = this.props.entry;

		return (
			<InputWrapper entry={entry} label={this.props.label}>
				<div className={"Input"}>
					{ this.renderControl(entry.data) }
				</div>
			</InputWrapper>
		);
	}
}


export default Input;
