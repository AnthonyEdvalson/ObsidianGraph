import React from 'react';
import './Links.css';
import InputWrapper from '../InputWrapper';
//import Obsidian from 'obsidian';

class Links extends React.Component{
	constructor(props) {
		super(props);
		this.state = {
			choices: [],
			choicesLoaded: false
		};
	}

	componentDidMount() {
		this.props.remote.please("get_all", this.props.from, {}).then(data => {
			this.setState({
				choices: data,
				choicesLoaded: true
			});
		});
	}

	handleCheck(value, i) {
		console.log(value);
		//this.props.entry.set()
	}

	renderBody() {
		if (!this.state.choicesLoaded)
			return <div className="tile">Loading...</div>
		
		if (this.state.choices.length === 0)
			return <div className="tile">No data to display</div>

		return this.state.choices.map((v, i) => {
			let checked = false;//this.props.entry.data.some(v2 => v2.duck === v.id);

			return (
				<div className="tile" key={v ? v.id : undefined}>
					<input type="checkbox" checked={checked} onChange={e => this.handleCheck(e.target.checked, i)} />
					{this.props.children(v)}
				</div>
			);
		})
	}

	render()
	{
		let entry = this.props.entry;

		return (
			<InputWrapper entry={entry} label={this.props.label}>
				<div className="Links shimmer">
					{ this.renderBody() }
				</div>
			</InputWrapper>
		);
	}
}

export default Links;
