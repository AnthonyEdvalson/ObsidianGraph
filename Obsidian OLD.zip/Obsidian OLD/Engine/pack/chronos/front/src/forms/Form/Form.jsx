import React, { useState, useEffect } from 'react';
import { Formik } from 'formik';
import Obsidian from 'obsidian';

function Form(props) {
  let save = this.props.save;
  let del = this.props.delete;
  let load = this.props.load;

  const [initial, setInitial] = useState({});
  useEffect(() => {
    load.then(data => {
      setInitial(data);
    })
  }, []);

  return (
    <div className="Form">
      <Formik
        initialValues={{ email: '', password: '' }}
        onSubmit={(values, { setSubmitting }) => {
          save(values).then(() => {
              setSubmitting(false);
          });
        }}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          isSubmitting,
          /* and other goodies */
        }) => (
          <form onSubmit={handleSubmit}>
            <input
              type="email"
              name="email"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.email}
            />
            {errors.email && touched.email && errors.email}
            <input
              type="password"
              name="password"
              onChange={handleChange}
              onBlur={handleBlur}
              value={values.password}
            />
            {errors.password && touched.password && errors.password}
            <button type="submit" disabled={isSubmitting}>
              Submit
            </button>
          </form>
        )}
      </Formik>
    </div>
  );
};

export default Form;