import React from 'react';
import './Combobox.css';
import InputWrapper from '../InputWrapper';
//import Obsidian from 'obsidian';

class Combobox extends React.Component{
	constructor(props) {
		super(props);

		this.state = {
			open: false
		};

		this.handleClick = this.handleClick.bind(this);
		this.handleSelect = this.handleSelect.bind(this);
		this.handleBlur = this.handleBlur.bind(this);
	}

	renderTile(data, handleClick, isStatic=false) {
		// TODO make it possible to use a different key
		return (
			<div className={isStatic ? "tile static" : "tile"} key={data ? data.id : undefined} onClick={handleClick}>
				{this.props.children(data)}
			</div>
		);
	}

	renderDropdown() {
		if (!this.props.choicesEntry.loaded)
			return <div className="dropdown"><div className="tile">Loading...</div></div>

		if (this.props.choicesEntry.data.length === 0)
			return <div className="dropdown"><div className="tile">No data to display</div></div>

		return (
			<div className="dropdown">
				{ this.props.choicesEntry.data.map((v, i) => {
					return this.renderTile(v, e => this.handleSelect(v));
				})}
			</div>
		)
	}
	
	handleBlur() {
		this.setState({open: false});
	}

	handleClick(event) {
		if (!this.props.entry.loaded)
			return;

		this.setState(prev => ({
			open: !prev.open
		}));
	}

	handleSelect(data) {
		this.setState({open: false});
		this.props.entry.set(data);
	}

	render()
	{
		let entry = this.props.entry;

		let t = typeof(entry.data);
		let data = null;

		if (t === "number")
			data = this.props.choicesEntry.data.find(e => e.id === entry.data);
		if (t === "object")
			data = entry.data;

		return (
			<InputWrapper entry={entry} label={this.props.label}>
				<div className={this.state.open ? "Combobox open" : "Combobox"} tabIndex="0" onBlur={this.handleBlur}>
					<div className="input" onClick={this.handleClick}>
						{ this.renderTile(data, undefined, true) }
					</div>
					{ this.state.open ? this.renderDropdown() : null }
				</div>
			</InputWrapper>
		);
	}
}

export default Combobox;









