import Pick from './Pick';
export default Pick;