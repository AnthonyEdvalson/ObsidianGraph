import datetime

from obsidian import ObsidianPackage
from peewee import *


"""
SO FAR
1 hr to scaffold everything, ~30min was spent looking up datetime and peewee docs
"""


Chronos = ObsidianPackage("chronos")


class Activity(Chronos.Model):
    name = CharField()
    color = CharField()
    order = IntegerField()


class Timestamp(Chronos.Model):
    time = DateTimeField()
    activity = ForeignKeyField(Activity, backref="timestamps")
    duration = FloatField()


class Goal(Chronos.Model):
    weekday = IntegerField()
    hours = FloatField()
    activity = ForeignKeyField(Activity, backref="goals")


def get_day_bounds(dt=None):
    if not dt:
        dt = datetime.datetime.now()

    start = datetime.datetime.combine(dt.date(), datetime.time())
    end = datetime.datetime.combine(dt.date(), datetime.time(23, 59, 59))

    return start, end


class TimestampController(Chronos.CrudObject):
    name = "Timestamp"
    _model = Timestamp

    @staticmethod
    def get_day(day=None):
        start, end = get_day_bounds(day)
        return Timestamp.select().where(start <= Timestamp.time <= end)


class ActivityController(Chronos.CrudObject):
    name = "Activity"
    _model = Activity


class GoalController(Chronos.CrudObject):
    name = "Goal"
    _model = Goal

    @staticmethod
    def get_completion(day: datetime=None):
        if not day:
            day = datetime.datetime.now()

        weekday = day.weekday()
        goals = Goal.select().where(Goal.weekday == weekday)
        stamps = TimestampController.get_day(day)

        sums = {}

        for stamp in stamps:
            activity = stamp.activity.name
            if activity not in sums:
                sums[activity] = 0

            sums[activity] += stamp.duration

        response = []

        for goal in goals:
            target = goal.hours
            activity = goal.activity

            if activity in response:
                raise Exception("Duplicate Goals for {} on day {}".format(activity.name, weekday))

            response.append({
                "activity": activity,
                "target": target,
                "progress": sums[activity.name] if activity.name in sums else 0
            })

        response.sort(key=lambda x: x["activity"].order)

        return response
