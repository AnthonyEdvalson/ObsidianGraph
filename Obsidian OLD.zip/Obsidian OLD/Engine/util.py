import sqlite3
import sys
import os
import subprocess

from engine import start, TempCWD


def setup(path):
    path = os.path.abspath(path.strip("\\").strip("/"))

    if os.path.exists(path):
        raise Exception("Cannot create '{}', folder already exists".format(path))

    name = os.path.basename(path)

    dirs = [
        [""],
        ["back"],
        ["packages"]
    ]

    for steps in dirs:
        os.mkdir(os.path.join(path, *steps))

    files = [
        (["_detail.json"], "{\n\t\"v\": 0\n}\n"),
        (["README.md"], "# Sample Project"),
        (["back", "example.py"], "from packages.obsidian import route\n\n\n@route\ndef example():\n\treturn 123"),
        (["model.sql"], ""),
    ]

    for file, content in files:
        with open(os.path.join(path, *file), "w+") as f:
            f.write(content)

    with TempCWD(path):
        subprocess.check_call("npx create-react-app " + name, shell=True)

    os.rename(os.path.join(path, name), os.path.join(path, "front"))


def install(location, layers="bfm"):
    package_path = os.path.abspath(location)
    package_name = os.path.basename(package_path)
    current_path = os.getcwd()

    print("Installing {}...".format(package_name))

    if "f" in layers:
        # Expose source front for linking
        source_front_path = os.path.join(package_path, "front")
        with TempCWD(source_front_path):
            subprocess.check_call("npm link", shell=True)

        # Import source front by linking
        with TempCWD(os.path.abspath("./front")):
            print("Installing frontend with npm...")
            subprocess.check_call("npm link {}/front".format(package_path), shell=True)

    if "b" in layers:
        print("Installing backend with symlinks...")

        pack_path = os.path.join(current_path, "back", "pack")
        target = os.path.join(package_path, "back")
        link = os.path.join(pack_path, package_name)

        # Create pack module if it doesn't exist
        if not os.path.exists(pack_path):
            print("back does not have a pack module, so one will be added")
            os.mkdir(pack_path)
            open(os.path.join(pack_path, "__init__.py"), "a")

        # Remove any existing packs with the same name
        if os.path.lexists(link):
            os.remove(link)
            print("A Symlink at {} already existed and has been removed".format(link))

        # Link, directory symlinks on windows requires admin access, but NTFS junctions don't so using those on windows
        if os.name == "nt":
            subprocess.check_call('mklink /J "{}" "{}"'.format(link, target), shell=True)
        else:
            os.symlink(target, link)

    print("{} has been installed successfully".format(package_name))


def run(primary):
    start(primary)


def db(path="sqlite/main.db"):
    db = sqlite3.connect(path)
    db.text_factory = str
    cur = db.cursor()

    result = cur.execute("SELECT name FROM sqlite_master WHERE type='table';").fetchall()
    if not result:
        print("No tables")
        return

    table_names = sorted(list(zip(*result))[0])

    for table_name in table_names:
        result = cur.execute("PRAGMA table_info('%s')" % table_name).fetchall()
        count = cur.execute("SELECT COUNT(*) FROM {}".format(table_name)).fetchone()[0]
        print("\n{} ({})".format(table_name, count))
        for col in result:
            print("  {}{}: {} {} ({})".format(
                col[1],
                "*" * col[5],
                col[2].upper(),
                "NOT NULL" if col[3] == 1 else "NULL",
                col[4])
            )

    command = input("\n\nany actions?\n: ").split(" ")
    if command[0] == "delete":
        cur.execute("DROP TABLE " + command[1])

    db.close()


action = sys.argv[1]
args = sys.argv[2:]

if action == "setup":
    setup(*args)
elif action == "install":
    install(*args)
elif action == "run":
    run(*args)
elif action == "db":
    db(*args)
# elif action == "npm":
#    npm(*args)
else:
    raise Exception()
