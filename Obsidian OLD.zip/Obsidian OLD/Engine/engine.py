import importlib
import subprocess
import sys
import json
import os
import traceback
import atexit

from flask import Flask, request
from flask_cors import CORS

from obsidian import ObsidianPackage
from routing import RouteNode

app = Flask("Engine")
packs = {}
router = RouteNode("Router")
subprocs = []


def close_npm():
    for subproc in subprocs:
        subproc.kill()


atexit.register(close_npm)


def parse_request():
    data = json.loads(request.get_data())
    if not isinstance(data, dict):
        raise Exception("The Obsidian Engine could not understand the message '{}'. ".format(request.get_data()) +
                        "It was expecting a valid JSON dictionary.")

    max_version = 0

    if "v" not in data or data["v"] > max_version:
        raise Exception("The {} package uses Obsidian protocol {}, ".format(data["package"], data["v"]) +
                        "but the Obsidian Engine it is running on only supports protocol {} and below.\n".format(
                            max_version) +
                        "Either downgrade the package, or update the engine to resolve the issue.")

    data.pop("v")

    pack = data["pack"]
    verb = data["verb"]
    obj = data["obj"]
    args = data["args"]

    checks = [
        (pack, "pack", str),
        (verb, "verb", str),
        (obj, "obj", str),
        (args, "args", dict)
    ]

    for v, n, t in checks:
        if type(v) != t:
            msg = "Request has an invalid param type, {} should be a {} but is a {}"
            raise Exception(msg.format(n, t.__name__, type(v).__name__))

    return [pack, obj, verb], args


@app.route("/call", methods=["POST"])
def call():
    req = parse_request()
    handler = router.route(req[0])
    return handler.call(req[1])


@app.errorhandler(Exception)
def handle_uncaught(e):
    if hasattr(e, "original_exception"):
        e = e.original_exception

    cwd = os.path.realpath(os.getcwd())

    tb = []
    for frame in traceback.extract_tb(e.__traceback__):
        path = os.path.realpath(frame.filename)

        tb.append({
            "file": path,
            "line": frame.line,
            "lineno": frame.lineno,
            "frame": frame.name,
            "important": path.startswith(cwd)
        })

    data = json.dumps({
        "msg": str(e),
        "tb": list(tb),
        "type": type(e).__name__
    })

    return json.dumps(data), 500


def load_packages():
    pack_dirs = os.listdir("pack/")
    for pack_dir in pack_dirs:
        if pack_dir[0] not in {"_", "."}:
            load_package(pack_dir)


def load_package(pack_dir):
    module = importlib.import_module("pack." + pack_dir)
    package = None
    for attr_name in dir(module):
        if attr_name.startswith("_"):
            continue

        attr = getattr(module, attr_name)
        if issubclass(type(attr), ObsidianPackage):
            package = attr

    if not package:
        raise Exception("pack/{}/__init__.py does not contain an obsidian package".format(pack_dir))

    package.set_routes()
    packs[package.name] = package
    router.register_routable(package.name, package.route_node)


def start(*argv):
    if len(argv) != 2:
        raise Exception("Must always provide one argument, the name of the primary package to run")

    primary = argv[1]

    load_packages()

    prime_pack = packs[primary]

    prime_pack.publish()
    prime_pack.connect()

    subprocs.append(subprocess.Popen("npm start", shell=True, cwd="pack/{}/front".format(primary)))

    CORS(app, origins="http://localhost:3000")
    app.run()


class TempCWD:
    def __init__(self, new, sandbox=False):
        self.old = None
        self.new = new
        self.sandbox = sandbox

    def __enter__(self):
        self.old = os.getcwd()
        os.chdir(self.new)

        if self.sandbox:
            sys.path.insert(0, self.new)

    def __exit__(self, exc_type, exc_val, exc_tb):
        os.chdir(self.old)

        if self.sandbox:
            sys.path.remove(self.new)


if __name__ == '__main__':
    start(*sys.argv)
