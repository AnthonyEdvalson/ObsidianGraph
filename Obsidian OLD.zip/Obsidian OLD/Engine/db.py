import sqlite3


class Connection:
    def __init__(self, db_file=":memory:"):
        self.db_file = db_file
        self.conn = None

    def __enter__(self) -> sqlite3.Connection:
        self.conn = sqlite3.connect(self.db_file)
        return self.conn

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.conn:
            self.conn.close()


class Cursor:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.cursor = None

    def __enter__(self) -> sqlite3.Cursor:
        self.cursor = self.conn.cursor()
        return self.cursor

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.conn.commit()
        if self.cursor:
            self.cursor.close()


def publish(commands, db_file=":memory:"):
    with Connection(db_file) as conn:
        with Cursor(conn) as c:
            c.executescript(commands)
