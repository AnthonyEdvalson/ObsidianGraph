import functools
import json
import re
from typing import Tuple, List
import datetime
from dateutil import parser
from abc import abstractmethod

import peewee
import playhouse.shortcuts

from routing import RouteNode, Routable


class JsonEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.isoformat()

        if issubclass(type(obj), peewee.Query):
            return [ObsidianPackage.Object.model_to_dict(x) for x in obj]

        if issubclass(type(obj), peewee.Model):
            return ObsidianPackage.Object.model_to_dict(obj)

        return super(JsonEncoder, self).default(obj)


class ObsidianPackage:
    def __init__(self, name, db_path=None):
        if not db_path:
            db_path = "sqlite/{}.db".format(name)

        pattern = r"^[a-z_][a-z_0-9]*$"
        if not re.match(pattern, name):
            raise Exception("Package names can only contain lowercase letters, numbers, and underscores,"
                            "and can't start with a number (RegEx: {})".format(pattern))

        self.name = name
        self.route_node = RouteNode(self.name)
        self.db = peewee.SqliteDatabase(db_path)

        self._model_class = None
        self.directory = "pack/" + name + "/"
        self.front_directory = self.directory + "front/"

    def _get_models(self):
        return self.Model.__subclasses__()

    def set_routes(self):
        clss = self.Object.__subclasses__()
        clss.extend(self.CrudObject.__subclasses__())
        clss.remove(self.CrudObject)
        for cls in clss:
            cls.package = self
            obj = cls()
            self.route_node.register_routable(obj.name, obj)

    def publish(self):
        self.db.create_tables(self._get_models())

    def unpublish(self):
        self.db.drop_tables(self._get_models())

    def connect(self):
        self.db.connect(True)

    @property
    def Model(self):
        if not self._model_class:
            meta = type("Meta", (object, ), {"database": self.db})
            class_dict = {"Meta": meta}
            self._model_class = type("Model", (peewee.Model, ), class_dict)

        return self._model_class

    class Object(Routable):
        package: 'ObsidianPackage' = None

        def __init__(self):
            cls = type(self)
            self.name = cls.name if hasattr(cls, "name") else cls.__name__
            self.name = self.name.lower()
            self.route_node = RouteNode(self.name)

            for k in dir(self):
                if k.startswith("_") or k == "route_and_call":
                    continue

                v = getattr(self, k)

                if callable(v):
                    self.route_node.register_function(k, self._route(v))

        @staticmethod
        def model_to_dict(data):
            return playhouse.shortcuts.model_to_dict(data)

        @staticmethod
        def _route(handler):
            name = handler.__name__

            @functools.wraps(handler)
            def wrapped_handler(**values):
                print("REQ: {} {}".format(name, values))
                data = handler(**values)

                res = json.dumps(data, cls=JsonEncoder, indent=2)
                print("RES: {}".format(res))
                return res

            return wrapped_handler

        def route(self, keys):
            return self.route_node.route(keys)

        def call(self, kwargs):
            return self.route_node.call(kwargs)

        def options(self):
            return self.route_node.options()

    class CrudObject(Object):
        _model = None

        @classmethod
        def get_new(cls):
            """
            Create a new entry, without adding it to the database
            :return: The default entry
            """
            return cls._model()

        @classmethod
        def get(cls, id):
            """
            Get an entry from the database
            :param id: The id of the row to pull from
            :return: A complete entry, with the same id given.
            """
            return cls._model.get(cls._model.id == id)

        @classmethod
        def set(cls, data):
            """
            Update an existing entry in the database
            :param data: new data for the entry
            :return: None
            """
            model = cls._model

            if "id" not in data:
                msg = "Cannot update a database entry without an id, " \
                      "make sure 'data.id' exists in the arguments sent"
                raise Exception(msg)

            with cls.package.db.atomic():
                row = model.get_by_id(data["id"])

                for k, v in data.items():
                    if type(v) is dict:
                        setattr(row, k, v["id"])
                    else:
                        setattr(row, k, v)

                row.save()

                return model.get_by_id(data["id"])

        @classmethod
        def insert(cls, data):
            """
            Update an existing entry in the database
            :param data: new data for the entry
            :return: None
            """
            with cls.package.db.atomic():
                model = cls._model
                row = model(**data)
                row.save()

                return model.get_by_id(row.id)

        @classmethod
        def delete(cls, data):
            """
            Attempted to delete an existing entry in the database
            :param data: the entry to delete
            :return: If a row was deleted
            """
            model = cls._model
            return model.delete().where(model.id == data["id"]).execute() > 0

        @classmethod
        def get_all(cls):
            """
            Get all entries in the database
            :return: all entries in the database
            """
            return cls._model.select()

    class MtMObject(CrudObject):
        _key_names: Tuple[str, str] = None
        _models: Tuple[peewee.Model, peewee.Model] = None

        @classmethod
        def _resolve_keys(cls, key) -> Tuple[peewee.Model, peewee.Model, str, str]:
            if key not in cls._key_names:
                msg = "Key '{}' is invalid, valid keys are {}".format(key, " and ".join(list(cls._key_names)))
                raise Exception(msg)

            this_i = cls._key_names.index(key)
            that_i = 1 - this_i

            return cls._models[this_i], cls._models[that_i], cls._key_names[this_i], cls._key_names[that_i]

        @classmethod
        def get_related(cls, **kwargs):
            """
            Get the list of entries related to the given model
            :param kwargs: {name: id} where name is the name of the model being referenced.
            :return: A list entries related to the given entry.
            """
            model_name, id = list(kwargs.items())[0]
            this, that, _, _ = cls._resolve_keys(model_name)

            return that.select().join(cls._model).join(this).where(this.id == id)


class ObsidianNode:
    @abstractmethod
    def process(self, *args, **kwargs):
        pass


class ObsidianContent:
    pass


class FieldContent(ObsidianContent):
    def __init__(self, name: str, col_type: str):
        self.name = name
        self.col_type = col_type


class TableContent(ObsidianContent):
    def __init__(self, name: str, fields: List[FieldContent]):
        self.name = name
        self.fields = fields


class TableNode(ObsidianNode):
    def __init__(self, name: str, fields: List[FieldContent]):
        self.name = name
        self.fields = fields

    def process(self):
        return TableContent(self.name, self.fields)


# ==================================


class FileContent(ObsidianContent):
    def __init__(self, path: str):
        self.path = path


class FileNode(ObsidianNode):
    def __init__(self, path: str):
        self.path = path

    def process(self):
        return FileContent(self.path)


# =====================================


class ObjectNode(ObsidianNode):
    def __init__(self, name: str, file: FileContent):
        self.name = name
        self.file = file

    def process(self, *tables):
        pass


# =====================================


class CRUDNode(ObjectNode):
    def __init__(self, name):
        super().__init__(name, FileContent(""))

    def process(self, table):
        super().process(table)


class JSNode(ObsidianNode):
    def __init__(self, ):
        pass


# =====================================


class PageNode(JSNode):
    pass


class RouterNode(JSNode):
    pass


class AppNode(JSNode):
    pass
