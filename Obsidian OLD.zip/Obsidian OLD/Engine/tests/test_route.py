import pytest

from Engine import route, routing


@route
def handler_zero():
    return 0


@route
def handler_add(a, b):
    return a + b


@route
def handler_inc(a, b=1):
    return a + b


@route
def handler_sum(*v):
    return sum(v)


@route
def handler_dict(pre, **kwargs):
    return pre + " | ".join(["{}: {}".format(k, v) for k, v in kwargs.items()])


@route
def handler_str(obj):
    return str(obj)


r = routing.Router()
r.register_package("default")
r.register_handler("default", "zero", handler_zero)
r.register_handler("default", "add", handler_add)
r.register_handler("default", "str", handler_str)
r.register_handler("default", "inc", handler_inc)
r.register_handler("default", "dict", handler_dict)


def test_simple():
    assert r.route_and_call("default", "zero") == "0"


def test_args():
    assert r.route_and_call("default", "add", {"a": 2, "b": 3}) == "5"


def test_complex_args():
    args = {
        "obj": {
            "list": [1, 2, 3],
            "attr": False
        }
    }
    assert r.route_and_call("default", "str", args) == "\"{'list': [1, 2, 3], 'attr': False}\""


def test_default_args():
    assert r.route_and_call("default", "inc", {"a": 2}) == "3"
    assert r.route_and_call("default", "inc", {"a": 2, "b": 3}) == "5"


def test_missing_arg():
    with pytest.raises(routing.MissingArgumentException):
        r.route_and_call("default", "add", {"a": 4})


def test_extra_arg():
    with pytest.warns(routing.ExtraArgumentWarning):
        r.route_and_call("default", "str", {"obj": 6, "extra": [1, 2, 3]})


def test_duplicate_register():

    @route
    def add(x):
        return x * 2

    with pytest.raises(routing.RouteKeyAlreadyExistsException):
        r.register_handler("default", "add", add)


def test_invalid_key():
    with pytest.raises(routing.RoutingException):
        r.route_and_call("default", "garbage", {"a": 15})


def test_register_invalid():
    with pytest.raises(routing.InvalidSignatureException):
        r.register_handler("default", "sum", handler_sum)


def test_kwargs():
    assert r.route_and_call("default", "dict", {"a": 4, "pre": "123|", "b": [1]}) == "\"123|a: 4 | b: [1]\""
    assert r.route_and_call("default", "dict", {"pre": "123|"}) == "\"123|\""
    with pytest.raises(routing.MissingArgumentException):
        r.route_and_call("default", "dict", {"a": 4, "b": [1]})


def test_packages():

    @route
    def add(x):
        return x * 3

    r.register_package("alt")
    r.register_handler("alt", "add", add)

    assert r.route_and_call("default", "add", {"a": 1, "b": 2}) == "3"
    assert r.route_and_call("alt", "add", {"x": 2}) == "6"
