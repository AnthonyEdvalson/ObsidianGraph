import inspect
import warnings
from typing import Dict, Any, Set, List
from abc import ABC, abstractmethod


class Routable(ABC):
    @abstractmethod
    def route(self, keys: List[str]) -> 'Routable':
        pass

    @abstractmethod
    def call(self, kwargs: Dict[str, Any]) -> Any:
        pass

    @abstractmethod
    def options(self) -> Dict[str, str]:
        pass


class RouteNode(Routable):
    def __init__(self, name):
        self.name = name
        self.lookup: Dict[str, Routable] = {}

    def __str__(self):
        return "RouteNode {}".format(self.name)

    def register_function(self, key, func):
        self._register(key, RouteHandler(key, func))

    def register_routable(self, key, node):
        self._register(key, node)

    def _register(self, key, value):
        if not issubclass(type(value), Routable):
            raise Exception("Can only register handlers that inherit from Routable, '{}' does not".format(type(value).__name__))

        key = key.lower()

        if key in self.lookup:
            msg = "Cannot register '{}', because it is already registered  in '{}' by '{}'".format(key, self.name, self.lookup[key])
            raise RouteKeyAlreadyExistsException(msg)

        self.lookup[key] = value

    def route(self, keys: List[str]) -> Routable:
        if not keys:
            return self

        key = keys.pop(0).lower()

        if key not in self.lookup:
            raise RoutingException(key, set(self.lookup.keys()), self.name)

        return self.lookup[key].route(keys)

    def call(self, kwargs: Dict[str, Any]) -> Any:
        msg = "Cannot call {} directly, you must call one of it's children ({})"
        raise Exception(msg.format(self.name, tuple(self.lookup.keys())))

    def options(self) -> Dict[str, str]:
        return {k: v.__doc__ for k, v in self.lookup.items()}


class RouteHandler(Routable):
    def __init__(self, key, handler):
        self.key = key.lower()
        sig = inspect.signature(handler)

        self.required = set()
        self.used = set()
        self.kwargs = False

        for name, param in sig.parameters.items():
            if param.kind in {inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY}:
                self.used.add(name)
                if param.default == inspect.Parameter.empty:
                    self.required.add(name)

            elif param.kind == inspect.Parameter.VAR_KEYWORD:
                self.kwargs = True
            else:
                msg = "Obsidian only supports handlers with arguments that can be passed with **kwargs\n" + \
                      "The argument '{}' in '{}' violates this rule".format(name, key)

                raise InvalidSignatureException(msg)

        self.handler = handler

    def route(self, keys: List[str]) -> Routable:
        if len(keys) > 0:
            raise RoutingException(keys[0], [], self.key)

        return self

    def call(self, kwargs: Dict[str, Any]) -> Any:
        args = set(kwargs.keys())

        missing = self.required.difference(args)
        if len(missing) > 0:
            raise MissingArgumentException(self.key, self.required, args)

        # TODO do type checking with type annotations if they are present in the handler
        if not self.kwargs:
            extra = args.difference(self.used)
            if len(extra) > 0:
                warnings.warn(ExtraArgumentWarning(self.key, self.used, args))
                for k in extra:
                    kwargs.pop(k)

        return self.handler(**kwargs)

    def options(self) -> Dict[str, str]:
        return {
            "*": self.handler.__doc__
        }


class InvalidSignatureException(Exception):
    pass


def _format_args(args):
    return"[{}]".format(", ".join(sorted(list(args))))


class MissingArgumentException(Exception):
    def __init__(self, key, requires, received):
        requires = _format_args(requires)
        received = _format_args(received)
        msg = "{} requires the arguments {}, but only received {}.".format(key, requires, received)
        super().__init__(msg)


class ExtraArgumentWarning(Warning):
    def __init__(self, key, args: Set, received):
        args = _format_args(args)
        received = _format_args(received)
        msg = "{} only needs the arguments {}, but received {}.".format(key, args, received)
        super().__init__(msg)


class RoutingException(Exception):
    def __init__(self, missing_key, valid_keys, parent):
        valid_str = ", ".join(sorted(list(valid_keys)))
        super().__init__("Could not find '{}' in {}. Valid keys are '{}'".format(missing_key, parent, valid_str))


class RouteKeyAlreadyExistsException(Exception):
    pass
