
## Obsidian Editor

The Obsidian Editor is a tool to create websites quickly by automatically generating code and structures for simple
applications. The details of the editor are still being figured out, but the ultimate goal is for common tasks to be
made much simpler. For example, getting a row from the database can be done in the editor by clicking a "Get Data"
button, picking the table, and what variable to use for the key. It then automatically generates all the infrastructure
to get that data to the frontend.

# Details

## Packages

A package is a group of elements, controllers, and models that share a common purpose.
For example, you could create a form package that has textboxes, buttons, and checkboxes, along
with code to make them function on the frontend, and validation scripts on the backend. With a handful of packages
it would be possible to make an entire application by wiring various packages together.

The purpose of packages is to reduce repetition of code within and between applications. Obsidian plans to
implement and support the following official packages:

- Common DB operations
- Forms
- Validation
- Login & Sessions
- Common (Navigation, Carousels, Panels, etc.)
- Charts

All applications are considered packages internally for consistency and flexibility (principle 3). The only difference
between an application and package is how it was intended to be used. A package is designed to be used in other packages 
or in applications. Applications are designed to be used by a user. Although they could be imported into another
package, that was not their intention. 

Because applications are packages, Obsidian packages are considerably more powerful than conventional ones. This is
because a package is not just a bundle of code, it can do anything a web application can. This includes adding web
pages, API endpoints, database tables, backend code, frontend code, and React components.


### Bridged Scope

Packages in Obsidian have a lot of flexibility, but with great power comes great naming conflicts.
To use an example, if a validation package has an endpoint called "validate"
and a developer adds their own endpoint called "validate", what happens when a request from the frontend calls "validate"?
The root of this issue is scope. 

There are two sets of code, one from the user, the other from the validation package. 
All programming languages can deal with scoping issues like this, the problem is that scope is lost when a request
is sent over HTTP. To fix this, Obsidian bridges the scope by sending that information over HTTP.
Obsidian makes sure all js files on the frontend have access to the name of their parent package. 
When communicating with the backend, they automatically send that information with all AJAX messages. 
The backend then uses that information to properly route requests, and avoid naming conflicts.

```
<shard name>
|-control
| |-<controller 1 name>.py
| |-<contrller 2 name>.py
|
|-view
| |-elements
|
|-model.json
|-app.json

```

## Controller

The controller layer is in change of logic and transferring data between the model and view. However the implementation
is a bit different from most. All API calls must be a POST and go through a single route named `/call`

This is because a call to Obsidian's REST API is designed to mimic a python function call, since that's what it ultimately will be.
A call to Obsidian's API looks like this:

1. An element requests some data from the Obsidian link by calling `Obsidian.call("example", {a: 2, b: 3})`.
2. The Obsidian link forwards the message as an HTTP POST with the body `{ "name": "example", "args": {"a": 2, "b": 3}`.
3. The Obsidian engine receives the POST and calls the appropriate handler with arguments, in this case `example(a=2, b=3)`.
4. The response from `example(a=2, b=3)` is converted to JSON and sent in the response.
5. The Obsidian link parses the JSON response and sends the data back to the element.
6. The element now has the data it needs, and can update the UI, store the value, etc.

The benefits of all requests going to a single POST are:

- data has no limit to size, compared to a GET request which should be under 2048 characters.
- data can be sent without being URLEncoded
- routes don't need to be defined multiple times on the server. Tricky logic and parsing for default, optional, 
and positional arguments are all dealt with by analyzing the endpoint's function signature.
- No unhelpful 404 or 400 errors because of a typo, Obsidian can suggest similarly named endpoints if an invalid one is sent,
as well as detect which required parameters are missing.
- Enforces Principle #6: Fewer, more general interfaces beats many specialized ones. This way data can be passed
consistently across all endpoints, with fewer exceptions and special cases



## Entries & CrudObject

Entries and Crudobjects are how Obsidian helps with simple database accesses. It implements the basic CRUD operations 
with minimal code. 

### CrudObject

CrudObjects are a variant of a package's Object that contains endpoints for the CRUD operations,
as well as some useful endpoints like create_or_update. 

Here is a simple implementation of a CrudObject.

```python
class Duck(Ducklopedia.CrudObject):
    _model = model.Duck
    _default = {
        "name": "New Duck",
        "rating": 0,
        "featured": False
    }
``` 

This sets up the backend to handle Entries on the frontend

### Entry

An Entry is a component in React that has a bunch of boilerplate to handle loading and saving data from a CrudObject.
It handles common state information like `loading` `loaded` `dirty` `saving` and `error`, as well as the data from
the backend itself. This state info is made available to the Entry's children as an EntryValue object, which wraps
those values up nicely, it also contains various functions that can be called to invoke changes on the Entry.

A common use case for EntryValues is passing data to input fields. Rather than passing in `loaded`, `data`,
`handleChange`, and `name` to every input field, Obsidian's built in form package takes in the entire EntryValue
object, and then interacts with the parts it needs. 

EntryValues also have a handy `attr()` function, passing in the name of a child attribute will return a new EntryValue
but it only contains information about that attribute, and any changes to that child will notify its parent.
 
Entry itself has the following functions

|Function|Verb|Action|
|--------|----|------|
|load()|create / read| calls create() if the "new" flag is true, otherwise it calls read()|
|save()|insert / update| calls insert() if the "new" flag is true, otherwise it calls update() afterwards the new flag is set to false|
|delete()|delete| sends the current object to the server for deletion. Does not fail, if the object does not exist|
|set(value)| N/A | modified the local copy of the data, and marks the entry as dirty|
|reload()| create/read |reloads the data by getting data in the same manner as last time|

CrudObject has the following verbs

|Verb|Action|
|----|------|
|create| returns the default object with an undefined id, DOES NOT add it to the database|
|read  | gets an existing object from the database, will break if it cannot find a result|
|update| updates existing data in the database, an error is thrown if the existing data cannot be found. Returns the data saved |
|insert| adds a new entry to the database, an error is thrown if it would overwrite existing data. Returns the data saved |
|delete| sends the current object to the server for deletion. Does not fail if the object does not exist. Returns if an object was deleted|

update and insert were merged into upsert so simplify the process of saving data. However, create and read were not
merged, although the could have been. The problem is quirks that come from accidentally making new entries in the
database when data is missing or corrupt. Because of this all Entry components have a prop called "new" that must
be passed in, which determines if read() or create() is run when mounting. Also, splitting these two allow for different
parameters to be passed in to each function, which opens the possibility for factory patterns, where additional info is
needed to create a new object 